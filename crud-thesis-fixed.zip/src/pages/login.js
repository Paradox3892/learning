import { Box, Typography } from '@mui/material';

export default function Login() {
  return (
    <Box>
      <Typography>Login Page</Typography>
    </Box>
  );
}
