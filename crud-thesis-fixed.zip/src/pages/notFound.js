import { Typography } from '@mui/material';

export default function NotFound() {
  return <Typography>404</Typography>;
}
